# chrome-extension-bootstrap
Provides basic architecture to start building a chrome extension.

See the link https://developer.chrome.com/extensions/manifest to add more items to manifest.json
